import "../../style.css";
import { Helmet } from "react-helmet";
import { useState } from "react";
import { Link } from "react-router-dom";

function Curriculum() {

  const [course, setCourse] = useState("")
  // <div>
  //       <h2 style={{ color: "blue" }}>Course Details</h2>
  //       <p>
  //         <strong>Course Code:</strong> CS101
  //         <br />
  //         <strong>Course Title:</strong> Introduction to Programming
  //         <br />
  //         <strong>Units/Credits:</strong> 3<br />
  //         <strong>Semester Offered:</strong> Fall
  //         <br />
  //       </p>

  //       <h2 style={{ color: "blue" }}>Course Content</h2>
  //       <ul>
  //         <li>Week 1: Basics of Programming</li>
  //         <li>Week 2: Data Types and Variables</li>
  //         <li>Week 3: Control Structures</li>
  //         {/* ... and so on */}
  //       </ul>

  //       <h2 style={{ color: "blue" }}>Learning Outcomes</h2>
  //       <ul>
  //         <li>
  //           By the end of this course, students will be able to write basic
  //           programs using Python.
  //         </li>
  //         <li>
  //           Students will understand different data types and their
  //           applications.
  //         </li>
  //         <li>
  //           Students will be adept at using control structures like loops and
  //           conditionals.
  //         </li>
  //       </ul>

  //       <h2 style={{ color: "blue" }}>Assessment Methods</h2>
  //       <p>
  //         <strong>Weekly Quizzes:</strong> 30%
  //         <br />
  //         <strong>Midterm Exam:</strong> 30%
  //         <br />
  //         <strong>Final Project:</strong> 30%
  //         <br />
  //         <strong>Participation:</strong> 10%
  //         <br />
  //       </p>

  //       <h2 style={{ color: "blue" }}>Feedback and Improvement</h2>
  //       <ul>
  //         <li>
  //           Increased focus on practical assignments based on student feedback.
  //         </li>
  //         <li>
  //           Introduced pair programming sessions to enhance collaborative
  //           skills.
  //         </li>
  //       </ul>

  //       <h2 style={{ color: "blue" }}>Resources</h2>
  //       <ul>
  //         <li>
  //           <strong>Recommended Textbook:</strong> "Python for Beginners" by
  //           John Doe.
  //         </li>
  //         <li>
  //           <strong>Supplementary Materials:</strong> Online lectures, coding
  //           platforms, etc.
  //         </li>
  //       </ul>

  //       <h2 style={{ color: "blue" }}>Instructor Details</h2>
  //       <p>
  //         <strong>Name:</strong> Dr. Jane Smith
  //         <br />
  //         <strong>Qualifications:</strong> PhD in Computer Science
  //         <br />
  //         <strong>Email:</strong> jane.smith@university.edu
  //         <br />
  //       </p>

  //       <h2 style={{ color: "blue" }}>Student Feedback</h2>
  //       <p>
  //         <strong>Average Rating:</strong> 4.5/5
  //       </p>
  //       <ul>
  //         <li>"Loved the hands-on approach!"</li>
  //         <li>"Wish there were more real-world project examples."</li>
  //       </ul>
  //     </div>
  return (
    <>
      <Helmet>
        <title>Academic Program Homepage</title>
      </Helmet>
      
      <div className="form-group" style={{ textAlign: "center", margin: "2% 35%" }}>
            <h2 style={{margin: "10px"}}>Curriculum Review</h2>  
            <label htmlFor="course">Course:</label>
            <br/>
            <select
              style={{
                width: "50%",
                padding: "10px",
                borderRadius: "5px",
                border: "1px solid #ccc",
              }}
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              id="course"
              name="course"
              placeholder="Select course"
              required
            >
              
              <option value="Course1">Course1</option>
            </select>
          </div>
          <div style={{margin:" 0 5%", border:"1px black"}}>
          Need to show course content for the course selected from above drop down 

          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum
          fringilla maximus feugiat. Quisque urna mi, elementum eget nisl sed,
          mollis dapibus mi. Quisque vitae semper orci. Fusce mauris massa,
          porttitor ac enim sed, convallis finibus urna. Phasellus eget nulla
          rhoncus, pharetra felis et, semper augue. Nulla ornare velit a lacinia
          pellentesque. Vivamus cursus ipsum at tortor sagittis, a finibus diam
          vestibulum. Integer vitae sem ultrices, mollis orci eget, tristique
          lectus. Praesent suscipit nisi ac purus dictum egestas. Maecenas
          vulputate elit vel nisi accumsan, vitae facilisis odio mattis. Donec
          mollis faucibus ipsum vel sodales. Praesent aliquet luctus nisi, vel
          interdum neque viverra ut. Sed est massa, placerat non nisi nec,
          tincidunt mollis sapien. Aliquam erat elit, fermentum vestibulum arcu
          ut, tempus vestibulum dui. Fusce luctus eleifend interdum. Donec
          facilisis hendrerit elit id maximus. Mauris ut blandit nunc, a
          eleifend justo. Duis viverra porta odio, vitae porttitor quam
          ultricies at. Quisque hendrerit purus sit amet nisi mattis mollis.
          Morbi mollis laoreet quam. Donec porta ullamcorper tempus. Mauris
          dictum hendrerit nunc, dapibus convallis augue. In suscipit rutrum
          iaculis. Cras lacinia nunc feugiat turpis tincidunt, vitae sodales
          libero sodales. Integer commodo congue dolor, in porta magna malesuada
          ut. Curabitur posuere tortor nulla, vel tincidunt turpis posuere non.
          Aenean vestibulum eleifend ultricies. Maecenas dolor enim, elementum
          ac lacinia suscipit, luctus id tortor. Integer cursus magna odio, eget
          porttitor libero aliquam non. Nam at ex ipsum. Phasellus posuere
          tristique felis vel interdum. Nam condimentum venenatis magna varius
          tristique. Mauris et varius est, in placerat lectus. Donec lorem
          massa, scelerisque non diam a, pellentesque dapibus arcu. Nam aliquam
          vestibulum ligula. Vestibulum et posuere risus. Aliquam consequat
          tincidunt tempor. Maecenas venenatis mi eget posuere mattis. Duis
          sollicitudin tellus a iaculis pellentesque. Mauris
          </div>

        <div style={{textAlign:"center", margin:"10px"}}>
          <Link to="/enhancement">
            <button style={{
              margin: "10px 35% 0 35%;",
              /* width: "100%", */
              padding: "10px",
              backgroundColor: "#007BFF",
              color: "#fff",
              borderRadius: "5px",
              border: "none",
              fontFamily: "Arial, sans-serif",
              cursor: "pointer",
            }}>Update</button>
          </Link>
        </div>
    </>
  );
}

export default Curriculum;
