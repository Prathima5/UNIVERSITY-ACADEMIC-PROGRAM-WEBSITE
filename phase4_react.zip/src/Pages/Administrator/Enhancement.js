import "../../style.css";
import { Helmet } from "react-helmet";

function Enhancement() {
//   <div
//   style={{
//     maxWidth: "800px",
//     margin: "auto",
//     fontFamily: "Arial, sans-serif",
//   }}
// >
//   <h1
//     style={{
//       textAlign: "center",
//       borderBottom: "2px solid black",
//       paddingBottom: "10px",
//     }}
//   >
//     Enhancement
//   </h1>

//   <div
//     style={{
//       margin: "20px 0",
//       backgroundColor: "#f9f9f9",
//       padding: "20px",
//       borderRadius: "5px",
//       boxShadow: "0px 0px 10px #aaa",
//     }}
//   >
//     <p style={{ color: "gray", fontSize: "20px", marginBottom: "10px" }}>
//       <strong>Course Title:</strong> Advanced Machine Learning
//     </p>

//     <p
//       style={{ color: "blue", fontWeight: "bold", marginBottom: "10px" }}
//     >
//       Professor: Dr. John Doe
//     </p>

//     <p style={{ fontStyle: "italic", margin: "20px 0", color: "#333" }}>
//       This course delves into the complexities of advanced machine
//       learning algorithms, understanding deep neural networks, and
//       exploring the latest advancements in artificial intelligence.
//     </p>

//     <div style={{ marginBottom: "20px" }}>
//       <span
//         style={{
//           textDecoration: "underline",
//           fontWeight: "bold",
//           fontSize: "18px",
//         }}
//       >
//         Course Outline:
//       </span>

//       <ul
//         style={{
//           marginLeft: "40px",
//           marginTop: "10px",
//           listStyleType: "disc",
//         }}
//       >
//         <li>Introduction to Advanced ML</li>
//         <li>Deep Neural Networks</li>
//         <li>Convolutional Neural Networks</li>
//         <li>Recurrent Neural Networks</li>
//         <li>Generative Adversarial Networks</li>
//         <li>Reinforcement Learning</li>
//       </ul>
//     </div>

//     <p style={{ color: "green", marginBottom: "10px" }}>
//       <strong>Prerequisites:</strong> Basic knowledge of machine learning,
//       linear algebra, and proficiency in Python.
//     </p>

//     <div
//       style={{
//         backgroundColor: "#f5f5f5",
//         padding: "10px",
//         borderRadius: "5px",
//         margin: "20px 0",
//       }}
//     >
//       <strong>Student Testimonials:</strong>
//       <blockquote
//         style={{
//           margin: "10px 0",
//           padding: "10px",
//           borderLeft: "5px solid blue",
//         }}
//       >
//         "This was one of the most engaging courses I've taken. Dr. Doe's
//         approach to teaching complex algorithms is simply unparalleled." -
//         Jane Smith, Class of 2022
//       </blockquote>
//     </div>
//   </div>
//   </div>
  return (
    <>
      <Helmet>
        <title>Academic Program Homepage</title>
      </Helmet>

      <h2 style={{textAlign : "center"}}>Update Course content</h2>
      <div style={{margin:"3% 5%", height:"300px"}}>
        <textarea style={{width: "100%", height:"100%"}}>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum
          fringilla maximus feugiat. Quisque urna mi, elementum eget nisl sed,
          mollis dapibus mi. Quisque vitae semper orci. Fusce mauris massa,
          porttitor ac enim sed, convallis finibus urna. Phasellus eget nulla
          rhoncus, pharetra felis et, semper augue. Nulla ornare velit a lacinia
          pellentesque. Vivamus cursus ipsum at tortor sagittis, a finibus diam
          vestibulum. Integer vitae sem ultrices, mollis orci eget, tristique
          lectus. Praesent suscipit nisi ac purus dictum egestas. Maecenas
          vulputate elit vel nisi accumsan, vitae facilisis odio mattis. Donec
          mollis faucibus ipsum vel sodales. Praesent aliquet luctus nisi, vel
          interdum neque viverra ut. Sed est massa, placerat non nisi nec,
          tincidunt mollis sapien. Aliquam erat elit, fermentum vestibulum arcu
          ut, tempus vestibulum dui. Fusce luctus eleifend interdum. Donec
          facilisis hendrerit elit id maximus. Mauris ut blandit nunc, a
          eleifend justo. Duis viverra porta odio, vitae porttitor quam
          ultricies at. Quisque hendrerit purus sit amet nisi mattis mollis.
          Morbi mollis laoreet quam. Donec porta ullamcorper tempus. Mauris
          dictum hendrerit nunc, dapibus convallis augue. In suscipit rutrum
          iaculis. Cras lacinia nunc feugiat turpis tincidunt, vitae sodales
          libero sodales. Integer commodo congue dolor, in porta magna malesuada
          ut. Curabitur posuere tortor nulla, vel tincidunt turpis posuere non.
          Aenean vestibulum eleifend ultricies. Maecenas dolor enim, elementum
          ac lacinia suscipit, luctus id tortor. Integer cursus magna odio, eget
          porttitor libero aliquam non. Nam at ex ipsum. Phasellus posuere
          tristique felis vel interdum. Nam condimentum venenatis magna varius
          tristique. Mauris et varius est, in placerat lectus. Donec lorem
          massa, scelerisque non diam a, pellentesque dapibus arcu. Nam aliquam
          vestibulum ligula. Vestibulum et posuere risus. Aliquam consequat
          tincidunt tempor. Maecenas venenatis mi eget posuere mattis. Duis
          sollicitudin tellus a iaculis pellentesque. Mauris
        </textarea>
      </div>
     
    </>
  );
}

export default Enhancement;
