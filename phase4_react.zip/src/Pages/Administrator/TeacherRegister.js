import React from "react";

function TeacherRegister() {
  return (
    <div>
      <h1>Work in Progress</h1>
    </div>
  );
}

export default TeacherRegister;
