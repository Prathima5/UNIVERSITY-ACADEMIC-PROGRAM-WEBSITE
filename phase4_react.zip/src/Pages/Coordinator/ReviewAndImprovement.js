import React, { useState, useEffect } from "react";
import axios from "../../components/axios";
import { Helmet } from "react-helmet";

function CourseManagement() {
  const [courses, setCourses] = useState([]);

  const [errorMessage, setErrorMessage] = useState("");

  async function fetchCourses() {
    try {
      const response = await axios.post("/getCourses");

      if (response.data.success) {
        setCourses(response.data.data);
      } else {
        setErrorMessage("Error fetching courses: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error fetching courses: " + error);
    }
  }

  useEffect(() => {
    fetchCourses();
  }, []);

  const deleteCourse = async (id) => {
    try {
      const formData = new URLSearchParams();
      formData.append("course_id", id);

      const response = await axios.post("/deleteCourse", formData);

      if (response.data.success) {
        const updatedCourses = courses.filter((course) => course.id !== id);
        setCourses(updatedCourses);
      } else {
        setErrorMessage("Error deleting course: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error deleting course: " + error);
    }
  };

  return (
    <>
      <Helmet>
        <title>Course Enhancement</title>
      </Helmet>

      <h2 style={{ textAlign: "center" }}>Course Enhancement</h2>
      <div style={{ textAlign: "center", margin: "3% 35%" }}>
        <table
          style={{
            width: "400px",
            margin: "20px",
            borderCollapse: "collapse",
            textAlign: "left",
            border: "1px solid #ddd",
          }}
        >
          <thead>
            <tr style={{ backgroundColor: "#f2f2f2" }}>
              <th style={{ padding: "12px" }}>Course ID</th>
              <th style={{ padding: "12px" }}>Course Name</th>
              <th style={{ padding: "12px" }}>Course Content</th>
              <th style={{ padding: "12px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {courses.map((course) => (
              <tr key={course.id} style={{ borderBottom: "1px solid #ddd" }}>
                <td style={{ padding: "12px" }}>{course.id}</td>
                <td style={{ padding: "12px" }}>{course.courseName}</td>
                <td style={{ padding: "12px" }}>{course.courseDescription}</td>
                <td style={{ padding: "12px" }}>
                  <button
                    onClick={() => deleteCourse(course.id)}
                    style={{
                      backgroundColor: "#ff4d4d",
                      color: "white",
                      border: "none",
                      borderRadius: "4px",
                      padding: "5px 10px",
                      marginBottom: "5px",
                    }}
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default CourseManagement;
