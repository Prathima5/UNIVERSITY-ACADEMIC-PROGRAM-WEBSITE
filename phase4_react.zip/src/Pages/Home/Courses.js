import React, { useState, useEffect } from "react";
import axios from "../../components/axios";
import { Helmet } from "react-helmet";

function Courses() {
  const [courses, setCourses] = useState([]);
  const [enrollments, setEnrollments] = useState([]);

  const [errorMessage, setErrorMessage] = useState("");

  const userEmail = localStorage.getItem("userEmail"); // Retrieve the user email from localStorage

  async function fetchCoursesAndEnrollment() {
    try {
      // Fetch all courses
      const coursesResponse = await axios.post("/getCourses");
      if (!coursesResponse.data.success) {
        setErrorMessage(
          "Error fetching courses: " + coursesResponse.data.message
        );
        return;
      }

      // Fetch user's enrollments
      const formData = new URLSearchParams();
      formData.append("email", userEmail);
      const enrollmentResponse = await axios.post(
        "/getStudentCourses",
        formData
      );
      if (!enrollmentResponse.data.success) {
        setErrorMessage(
          "Error fetching enrollment status: " + enrollmentResponse.data.message
        );
        return;
      }

      // Combine courses with enrollment status
      const combinedCourses = coursesResponse.data.data.map((course) => ({
        ...course,
        is_enrolled: !!enrollmentResponse.data.data.find(
          (enrollment) => enrollment.course_name === course.courseName
        )?.is_enrolled,
      }));

      setCourses(combinedCourses);
    } catch (error) {
      setErrorMessage("Error fetching data: " + error.message);
    }
  }

  useEffect(() => {
    fetchCoursesAndEnrollment();
  }, []);

  const handleEnrollment = async (courseName) => {
    const formData = new URLSearchParams();
    formData.append("email", userEmail);
    formData.append("courseName", courseName);

    try {
      const response = await axios.post("/enrollCourse", formData);
      if (response.data.success) {
        // Update the local state to reflect the change
        fetchCoursesAndEnrollment(); // Refetch courses to update the UI
      } else {
        setErrorMessage("Error enrolling in course: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error enrolling in course: " + error.message);
    }
  };

  return (
    <>
      <Helmet>
        <title>Currently Available Courses</title>
      </Helmet>
      <h1
        style={{
          textAlign: "center",
          margin: "40px 0",
          color: "#34495e",
          fontWeight: "500",
        }}
      >
        Available Courses
      </h1>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          backgroundColor: "#f8f9fa",
          padding: "20px",
          borderRadius: "15px",
          boxShadow: "0px 0px 15px rgba(0, 0, 0, 0.2)",
        }}
      >
        <table
          style={{
            width: "500px",
            margin: "20px",
            borderCollapse: "collapse",
            textAlign: "left",
            border: "1px solid #eaeaea",
          }}
        >
          <thead>
            <tr style={{ backgroundColor: "#eaeaea", color: "#34495e" }}>
              <th style={{ padding: "15px", fontSize: "16px" }}>Course ID</th>
              <th style={{ padding: "15px", fontSize: "16px" }}>Course Name</th>
              <th style={{ padding: "15px", fontSize: "16px" }}>
                Course Content
              </th>
            </tr>
          </thead>
          <tbody>
            {}
            {courses.map((course) => (
              <tr key={course.id} style={{ borderBottom: "1px solid #eaeaea" }}>
                <td style={{ padding: "15px", fontSize: "15px" }}>
                  {course.id}
                </td>
                <td style={{ padding: "15px", fontSize: "15px" }}>
                  {course.courseName}
                </td>
                <td style={{ padding: "15px", fontSize: "15px" }}>
                  {course.courseContent}
                </td>
                <td style={{ padding: "15px", fontSize: "15px" }}>
                  {course.is_enrolled ? (
                    <button
                      style={{ backgroundColor: "#d3d3d3" }}
                      disabled={true}
                    >
                      Enrolled
                    </button>
                  ) : (
                    <button onClick={() => handleEnrollment(course.courseName)}>
                      Enroll
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default Courses;
