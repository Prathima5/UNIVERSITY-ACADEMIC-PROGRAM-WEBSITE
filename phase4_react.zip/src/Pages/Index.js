import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import "../style.css";
import backgroundImage1 from "../Images/img1.jpg";
import slide1 from "../Images/slide1.jpg";
import slide2 from "../Images/slide2.jpg";
import slide3 from "../Images/slide3.jpg";
import axios from "../components/axios";

function Index() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  const [userRole, setUserRole] = useState("");

  async function getUserInfo() {
    // Check if the user is logged in and get their role
    const userEmail = localStorage.getItem("userEmail");
    const role = localStorage.getItem("userRole");

    const userNameRequest = new URLSearchParams();
    userNameRequest.append("email", userEmail);

    // Get the user's name from the API
    const response = await axios.post("/getUserInfo", userNameRequest);

    console.log(response);
    setUserName(response.data.data.name);
    setIsLoggedIn(userEmail !== null && userEmail !== "null");
    setUserRole(role);
  }

  async function getTest() {
    // Get the user's name from the API
    const response = await axios.post("/getUsers");

    console.log(response);
  }

  useEffect(() => {
    getUserInfo();
    getTest();
  }, []);

  const welcomeMessage = isLoggedIn
    ? `Hey ${userName}! Manage your academic progress here.`
    : "Sign in to manage your academic progress.";

  // Dummy future events
  const futureEvents = [
    "Volleyball Game - 12/05/2023   ",
    "Final Exams - 12/12/2023   ",
    "Homecoming Event - 12/20/2023   ",
    "Science Fair - 01/15/2024   ",
    "Alumni Meet & Greet - 02/22/2024   ",
  ];

  // const dummyPolicies = [
  //   {
  //     id: 1,
  //     title: "Library Access Policy",
  //     description:
  //       "Policy regarding the access to the university library facilities.",
  //     role: "Student",
  //   },
  //   {
  //     id: 2,
  //     title: "Faculty Evaluation Policy",
  //     description:
  //       "Guidelines on how faculty members are evaluated each semester.",
  //     role: "Admin",
  //   },
  // ];

  const [policies, setPolicies] = useState([]);

  async function fetchPolicies() {
    try {
      const response = await axios.post("/getQAPolicies");
      if (response.data.success) {
        setPolicies(response.data.policies);
      } else {
        console.log("Error fetching policies: " + response.data.message);
      }
    } catch (error) {
      console.log("Error fetching policies: " + error.message);
    }
  }

  useEffect(() => {
    fetchPolicies();
  }, []);

  const dummyPolicies = policies.map((policy) => ({
    id: policy.id,
    title: policy.policyName,
    description: policy.policyDesc,
    role: policy.policySubject,
  }));

  // Filter policies based on the user's role
  const filteredPolicies = dummyPolicies.filter(
    (policy) => policy.role === userRole
  );

  return (
    <div>
      <Helmet>
        <title>Academic Program Homepage</title>
      </Helmet>

      {/* First Division */}
      <div
        className="hero-section"
        style={{
          backgroundImage: `url(${backgroundImage1})`,
          textAlign: "center",
        }}
      >
        <div className="login-message">
          <h1>Welcome Back!</h1>
          <p>{welcomeMessage}</p>
          <br />
          {!isLoggedIn && (
            <Link to="/login" className="login-button">
              Login
            </Link>
          )}
        </div>
      </div>

      {/* Second Division - Image Boxes */}
      <div className="image-boxes-container">
        <div className="image-box">
          <img
            src={slide1}
            alt="Description of Image 1"
            className="image-box-img"
          />
          <p className="image-description">University Campus</p>
        </div>
        <div className="image-box">
          <img
            src={slide2}
            alt="Description of Image 2"
            className="image-box-img"
          />
          <p className="image-description">Open Library</p>
        </div>
        <div className="image-box">
          <img
            src={slide3}
            alt="Description of Image 3"
            className="image-box-img"
          />
          <p className="image-description">Activity Center</p>
        </div>
      </div>

      {/* Policies Section - Only shown if logged in */}
      {isLoggedIn && (
        <div className="policies-section">
          <h2>Policies Relevant to You</h2>
          {filteredPolicies.length > 0 ? (
            <div className="policies-container">
              {filteredPolicies.map((policy) => (
                <div key={policy.id} className="policy-card">
                  <h3>{policy.title}</h3>
                  <p>{policy.description}</p>
                </div>
              ))}
            </div>
          ) : (
            <p>No policies available to display for your role.</p>
          )}
        </div>
      )}

      {/* Third Division - Combined Content */}
      <div className="combined-section">
        {/* Ticker for Upcoming Events */}
        <div className="ticker-wrapper">
          <ul className="ticker">
            {futureEvents.map((event) => (
              <li key={event}>{event}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Index;
