import React, { useState, useEffect } from "react";
import axios from "../../components/axios";
import { Helmet } from "react-helmet";

function CourseManagement() {
  const [courses, setCourses] = useState([]);
  const [courseName, setCourseName] = useState("");
  const [courseContent, setCourseContent] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [editingCourseId, setEditingCourseId] = useState(null);
  const [editCourseName, setEditCourseName] = useState("");
  const [editCourseContent, setEditCourseContent] = useState("");

  async function fetchCourses() {
    try {
      const response = await axios.post("/getCourses");

      if (response.data.success) {
        setCourses(response.data.data);
      } else {
        setErrorMessage("Error fetching courses: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error fetching courses: " + error);
    }
  }

  const startEdit = (course) => {
    setEditingCourseId(course.id);
    setEditCourseName(course.courseName);
    setEditCourseContent(course.courseContent);
  };

  const cancelEdit = () => {
    setEditingCourseId(null);
    setEditCourseName("");
    setEditCourseContent("");
  };

  const saveCourse = async (id) => {
    try {
      const formData = new URLSearchParams();
      formData.append("course_id", id);
      formData.append("courseName", editCourseName);
      formData.append("courseContent", editCourseContent);

      const response = await axios.post("/editCourse", formData);

      if (response.data.success) {
        fetchCourses();
        cancelEdit();
      } else {
        setErrorMessage("Error saving course: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error saving course: " + error);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  const addCourse = async () => {
    try {
      const formData = new URLSearchParams();
      formData.append("courseName", courseName);
      formData.append("courseContent", courseContent);

      const response = await axios.post("/createCourse", formData);

      if (response.data.success) {
        fetchCourses();
        setCourseName("");
        setCourseContent("");
      } else {
        setErrorMessage("Error adding course: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error adding course: " + error);
    }
  };

  const deleteCourse = async (id) => {
    try {
      const formData = new URLSearchParams();
      formData.append("course_id", id);

      const response = await axios.post("/deleteCourse", formData);

      if (response.data.success) {
        const updatedCourses = courses.filter((course) => course.id !== id);
        setCourses(updatedCourses);
      } else {
        setErrorMessage("Error deleting course: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error deleting course: " + error);
    }
  };

  return (
    <>
      <Helmet>
        <title>Create Course</title>
      </Helmet>
      <h1 style={{ textAlign: "center", margin: "20px 0" }}>Create Course</h1>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div
          style={{
            margin: "20px",
            padding: "20px",
            border: "1px solid #ccc",
            borderRadius: "8px",
            width: "300px",
          }}
        >
          <label style={{ fontWeight: "bold" }}>Course Name:</label>
          <input
            type="text"
            value={courseName}
            onChange={(e) => setCourseName(e.target.value)}
            style={{
              width: "90%",
              padding: "10px",
              borderRadius: "5px",
              border: "1px solid #ccc",
              marginBottom: "10px",
            }}
            required
          />
          <label style={{ fontWeight: "bold" }}>Course Content:</label>
          <textarea
            type="text"
            value={courseContent}
            onChange={(e) => setCourseContent(e.target.value)}
            style={{
              width: "90%",
              padding: "10px",
              borderRadius: "5px",
              border: "1px solid #ccc",
            }}
            required
          />
          <button
            onClick={addCourse}
            style={{
              width: "auto",
              padding: "10px",
              backgroundColor: "#007bff",
              margin: "10px 30% 0 30%",
              color: "white",
              border: "none",
              borderRadius: "4px",
            }}
          >
            Add Course
          </button>
        </div>

        <table
          style={{
            width: "400px",
            margin: "20px",
            borderCollapse: "collapse",
            textAlign: "left",
            border: "1px solid #ddd",
          }}
        >
          <thead>
            <tr style={{ backgroundColor: "#f2f2f2" }}>
              <th style={{ padding: "12px" }}>Course ID</th>
              <th style={{ padding: "12px" }}>Course Name</th>
              <th style={{ padding: "12px" }}>Course Content</th>
              <th style={{ padding: "12px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {courses.map((course) => (
              <tr key={course.id} style={{ borderBottom: "1px solid #ddd" }}>
                <td style={{ padding: "12px" }}>{course.id}</td>
                {editingCourseId === course.id ? (
                  <>
                    <td style={{ padding: "12px" }}>
                      <input
                        type="text"
                        value={editCourseName}
                        onChange={(e) => setEditCourseName(e.target.value)}
                      />
                    </td>
                    <td style={{ padding: "12px" }}>
                      <textarea
                        value={editCourseContent}
                        onChange={(e) => setEditCourseContent(e.target.value)}
                      />
                    </td>
                  </>
                ) : (
                  <>
                    <td style={{ padding: "12px" }}>{course.courseName}</td>
                    <td style={{ padding: "12px" }}>{course.courseContent}</td>
                  </>
                )}
                <td style={{ padding: "12px" }}>
                  {editingCourseId === course.id ? (
                    <>
                      <button
                        onClick={() => saveCourse(course.id)}
                        style={
                          {
                            /* your styles */
                          }
                        }
                      >
                        Save
                      </button>
                      <button
                        onClick={cancelEdit}
                        style={
                          {
                            /* your styles */
                          }
                        }
                      >
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => startEdit(course)}
                        style={{
                          backgroundColor: "#dc3545",
                          color: "white",
                          border: "none",
                          borderRadius: "4px",
                          padding: "5px 10px",
                          cursor: "pointer",
                        }}
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => deleteCourse(course.id)}
                        style={{
                          backgroundColor: "#dc3545",
                          color: "white",
                          border: "none",
                          borderRadius: "4px",
                          padding: "5px 10px",
                          cursor: "pointer",
                        }}
                      >
                        Delete
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default CourseManagement;
