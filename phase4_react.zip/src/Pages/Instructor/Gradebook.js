import React from "react";
import { Helmet } from "react-helmet";
import axios from "../../components/axios";
import { useState, useEffect } from "react";

function Gradebook() {
  const [courses, setCourses] = useState([]);
  const [course, setCourse] = useState("");
  const [exams, setExams] = useState([]);
  const [filteredExams, setFilteredExams] = useState([]);
  const [studentCourses, setStudentCourses] = useState([]);
  const [filteredStudentCourses, setFilteredStudentCourses] = useState([]);
  const [users, setUsers] = useState([]);
  const [studentCoursesWithNames, setStudentCoursesWithNames] = useState([]);
  const [studentExamsMapping, setStudentExamsMapping] = useState([]);
  const [examGrades, setExamGrades] = useState([]);

  const fetchExamGrades = async () => {
    try {
      const response = await axios.get("/getExamGrades");
      if (response.data.success) {
        setExamGrades(response.data.data);
      } else {
        // Handle case where the fetch succeeded but no data was found
        console.error("Failed to fetch exam grades: ", response.data.message);
      }
    } catch (error) {
      // Handle any errors in fetching exam grades
      console.error("Error fetching exam grades: ", error);
    }
  };

  const fetchStudentCourses = async () => {
    const response = await axios.post("/getStudentCoursesInstructor");
    if (response.data.success) {
      setStudentCourses(response.data.data);
    }
  };

  const fetchUsers = async () => {
    const response = await axios.post("/getUserName");
    if (response.data.success) {
      setUsers(response.data.data);
    }
  };

  const fetchExams = async () => {
    const response = await axios.post("/getExams");
    if (response.data.success) {
      setExams(response.data.data);
    }
  };

  const fetchCourses = async () => {
    const response = await axios.get("/getCourses");
    if (response.data.success) {
      setCourses(response.data.data);
    }
  };

  const mapExamsToStudents = () => {
    const mappedData = [];
    studentCoursesWithNames.forEach((studentCourse) => {
      const matchedExams = filteredExams.filter(
        (exam) => exam.courseName === studentCourse.course_name
      );
      matchedExams.forEach((exam) => {
        const gradeInfo = examGrades.find(
          (grade) =>
            grade.name === studentCourse.name &&
            grade.examName === exam.examName &&
            grade.courseName === studentCourse.course_name
        );

        const mapping = {
          course_name: studentCourse.course_name,
          name: studentCourse.name,
          exam_name: exam.examName,
          grade: gradeInfo ? gradeInfo.grade : null,
          feedback: gradeInfo ? gradeInfo.feedback : null,
        };
        mappedData.push(mapping);
      });
    });
    return mappedData;
  };

  useEffect(() => {
    fetchExams();
    fetchCourses();
    fetchStudentCourses();
    fetchUsers();
    fetchExamGrades();
  }, []);

  useEffect(() => {
    if (course) {
      const studentCoursesByCourse = studentCourses.filter(
        (sc) => sc.course_name === course
      );

      const studentCoursesWithNames = studentCoursesByCourse.map((course) => {
        const user = users.find((user) => user.email === course.email);
        return { ...course, name: user ? user.name : "Jhon Smith" };
      });

      setStudentCoursesWithNames(studentCoursesWithNames);

      setFilteredStudentCourses(studentCoursesByCourse);

      const courseExams = exams.filter((exam) => exam.courseName === course);
      setFilteredExams(courseExams);
    }
  }, [course, exams, studentCourses, users]);

  useEffect(() => {
    const studentExamsMapping = mapExamsToStudents();
    setStudentExamsMapping(studentExamsMapping);
  }, [
    course,
    exams,
    studentCourses,
    users,
    filteredExams,
    studentCoursesWithNames,
    examGrades,
  ]);

  const handleGrade = async (mapping) => {
    if (mapping.grade < 0 || mapping.grade > 100) {
      alert("Grade must be between 0 and 100");
      return;
    }

    try {
      const formData = new URLSearchParams();
      formData.append("name", mapping.name);
      formData.append("course_name", mapping.course_name);
      formData.append("exam_name", mapping.exam_name);
      formData.append("grade", mapping.grade);
      formData.append("feedback", mapping.feedback);

      const response = await axios.post("/insertGrade", formData);

      if (response.data.success) {
        alert("Grade added successfully");
        fetchExamGrades();
      } else {
        alert("Error adding grade: " + response.data.message);
      }
    } catch (error) {
      // Handle error
      alert("Error adding grade: " + error);
    }
  };

  return (
    <>
      <Helmet>
        <title>Instructor's Gradebook</title>
      </Helmet>
      {console.log(studentExamsMapping)}
      {console.log(examGrades)}
      <div
        className="form-group"
        style={{ textAlign: "center", margin: "2% 35%" }}
      >
        <h2 style={{ margin: "10px 10px 20px 10px" }}>Exam grades</h2>
        <label htmlFor="course">Select Course</label>
        <br />
        <select
          style={{
            width: "50%",
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            margin: "5px",
          }}
          value={course}
          onChange={(e) => setCourse(e.target.value)}
          // id="course"
          // name="course"
          placeholder="Select course"
          required
        >
          {courses.map((course) => (
            <option key={course.id} value={course.courseName}>
              {course.courseName}
            </option>
          ))}
        </select>
      </div>

      <table
        style={{
          borderCollapse: "collapse",
          width: "100%",
          boxShadow: "0px 0px 5px rgba(0,0,0,0.5)",
          overflow: "hidden",
          borderRadius: "5px",
          marginTop: "20px",
        }}
      >
        <thead>
          <tr style={{ backgroundColor: "#007BFF", color: "#FFF" }}>
            <th style={{ padding: "10px 15px" }}>name</th>
            <th style={{ padding: "10px 15px" }}>Exam Name</th>
            <th style={{ padding: "10px 15px" }}>Grade</th>
            <th style={{ padding: "10px 15px" }}>Feedback</th>
            <th style={{ padding: "10px 15px" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {studentExamsMapping.map((mapping, index) => (
            <tr key={index} style={{ borderBottom: "1px solid #ddd" }}>
              <td style={{ textAlign: "center" }}>{mapping.name}</td>
              <td style={{ textAlign: "center" }}>{mapping.exam_name}</td>
              <td style={{ textAlign: "center" }}>
                <input
                  type="number"
                  value={mapping.grade ?? ""} // Use nullish coalescing to fall back to an empty string
                  placeholder="Enter grade"
                  onChange={(e) => {
                    const newGrade = e.target.value;
                    // Update only the grade, preserve the feedback
                    setStudentExamsMapping((prevMappings) =>
                      prevMappings.map((m, idx) =>
                        idx === index ? { ...m, grade: newGrade } : m
                      )
                    );
                  }}
                />
              </td>
              <td style={{ textAlign: "center" }}>
                <input
                  type="text"
                  value={mapping.feedback ?? ""} // Use nullish coalescing to fall back to an empty string
                  placeholder="Enter feedback"
                  onChange={(e) => {
                    const newFeedback = e.target.value;
                    // Update only the feedback, preserve the grade
                    setStudentExamsMapping((prevMappings) =>
                      prevMappings.map((m, idx) =>
                        idx === index ? { ...m, feedback: newFeedback } : m
                      )
                    );
                  }}
                />
              </td>
              <td>
                <button
                  onClick={() => handleGrade(mapping, index)} // Pass index if needed for identifying the mapping
                  style={{
                    padding: "5px 10px",
                    backgroundColor: "#007BFF",
                    color: "#FFF",
                    border: "none",
                    borderRadius: "5px",
                    cursor: "pointer",
                  }}
                >
                  Grade
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

export default Gradebook;
