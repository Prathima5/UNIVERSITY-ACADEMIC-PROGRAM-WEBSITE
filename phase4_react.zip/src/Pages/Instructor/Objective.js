import "../../style.css";
import { Helmet } from "react-helmet";

function Objective() {
  return (
    <>
      <Helmet>
        <title>Academic Program Homepage</title>
      </Helmet>
      <h1>Objective</h1>
      <div>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum
          fringilla maximus feugiat. Quisque urna mi, elementum eget nisl sed,
          mollis dapibus mi. Quisque vitae semper orci. Fusce mauris massa,
          porttitor ac enim sed, convallis finibus urna. Phasellus eget nulla
          rhoncus, pharetra felis et, semper augue. Nulla ornare velit a lacinia
          pellentesque. Vivamus cursus ipsum at tortor sagittis, a finibus diam
          vestibulum. Integer vitae sem ultrices, mollis orci eget, tristique
          lectus. Praesent suscipit nisi ac purus dictum egestas. Maecenas
          vulputate elit vel nisi accumsan, vitae facilisis odio mattis. Donec
          mollis faucibus ipsum vel sodales. Praesent aliquet luctus nisi, vel
          interdum neque viverra ut. Sed est massa, placerat non nisi nec,
          tincidunt mollis sapien. Aliquam erat elit, fermentum vestibulum arcu
          ut, tempus vestibulum dui. Fusce luctus eleifend interdum. Donec
          facilisis hendrerit elit id maximus. Mauris ut blandit nunc, a
          eleifend justo. Duis viverra porta odio, vitae porttitor quam
          ultricies at. Quisque hendrerit purus sit amet nisi mattis mollis.
          Morbi mollis laoreet quam. Donec porta ullamcorper tempus. Mauris
          dictum hendrerit nunc, dapibus convallis augue. In suscipit rutrum
          iaculis. Cras lacinia nunc feugiat turpis tincidunt, vitae sodales
          libero sodales. Integer commodo congue dolor, in porta magna malesuada
          ut. Curabitur posuere tortor nulla, vel tincidunt turpis posuere non.
          Aenean vestibulum eleifend ultricies. Maecenas dolor enim, elementum
          ac lacinia suscipit, luctus id tortor. Integer cursus magna odio, eget
          porttitor libero aliquam non. Nam at ex ipsum. Phasellus posuere
          tristique felis vel interdum. Nam condimentum venenatis magna varius
          tristique. Mauris et varius est, in placerat lectus. Donec lorem
          massa, scelerisque non diam a, pellentesque dapibus arcu. Nam aliquam
          vestibulum ligula. Vestibulum et posuere risus. Aliquam consequat
          tincidunt tempor. Maecenas venenatis mi eget posuere mattis. Duis
          sollicitudin tellus a iaculis pellentesque. Mauris elementum accumsan
          nibh, a facilisis turpis dictum vel. Phasellus eu libero velit.
          Suspendisse potenti. Integer hendrerit ante in consequat interdum. Sed
          justo augue, porttitor eget tristique vel, accumsan id libero.
          Pellentesque hendrerit sed nisi in lacinia. Nullam nec porttitor diam,
          non scelerisque eros. Duis dolor ipsum, ullamcorper quis viverra
          dapibus, viverra eu ex. Pellentesque vehicula porta ipsum a commodo.
          Integer et auctor justo. Sed eu faucibus ante. Aenean sagittis, nunc
          sed dictum tempor, massa est rhoncus augue, et varius augue lorem in
          nibh. Nunc laoreet nisl non gravida mattis. Donec aliquet ultricies
          mollis. Cras porta, turpis sed gravida scelerisque, urna lectus
          tincidunt nibh, et dictum erat nisi at orci. Integer eleifend erat
          arcu, ac laoreet ligula sagittis sit amet. Sed tempor congue euismod.
          Pellentesque efficitur accumsan ullamcorper. Ut tincidunt euismod
          aliquam. Vivamus nec porttitor lacus, eu dictum arcu. Integer eget
          velit non augue hendrerit scelerisque.
        </p>
      </div>
    </>
  );
}

export default Objective;
