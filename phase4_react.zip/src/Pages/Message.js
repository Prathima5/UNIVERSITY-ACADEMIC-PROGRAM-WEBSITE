import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../components/axios";
import { Link } from "react-router-dom";
import "../components/navbar.css";

function Message() {
  // const users = ["User 1", "User 2", "User 3", "User 4", "User 5"];
  const userEmail = localStorage.getItem("userEmail");
  const [apiResponse, setApiResponse] = useState([]);
  const [userNameMap, setUserNameMap] = useState({});
  const [userMessages, setUserMessages] = useState({});
  const [selectedUser, setSelectedUser] = useState("");
  const [currentMessage, setCurrentMessage] = useState("");
  const [processedIds, setProcessedIds] = useState(new Set());
  const messagesEndRef = useRef(null);
  const [isChatbotThinking, setIsChatbotThinking] = useState(false);

  let conversationHistory = [
    {
      role: "user",
      content:
        "Act as a chat bot deployed on student e-learning portal. Answer questions as short as possible max 5 lines.",
    },
  ];

  const getChatGPTResponse = async (conversationHistory) => {
    const apiKey = "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";
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    };
    const data = {
      model: "gpt-3.5-turbo",
      messages: conversationHistory,
    };

    try {
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        data,
        { headers }
      );
      return response.data;
    } catch (error) {
      console.error("Error fetching ChatGPT response:", error);
      return null;
    }
  };

  const addMessageAndGetResponse = async (userMessage) => {
    conversationHistory.push({ role: "user", content: userMessage });

    const response = await getChatGPTResponse(conversationHistory);

    let systemMessage = "";
    if (response) {
      systemMessage = response.choices?.[0]?.message?.content || "";

      if (systemMessage) {
        conversationHistory.push({ role: "system", content: systemMessage });
      }
    }

    return systemMessage;
  };

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollTop = messagesEndRef.current.scrollHeight;
    }
  };

  const fetchChats = async () => {
    const formData = new URLSearchParams();
    formData.append("email", userEmail);

    try {
      const response = await axios.post("/getChat", formData);
      if (response.data.success) {
        // Directly set the new messages
        setApiResponse(response.data.data);
      }
    } catch (error) {
      console.error("Error fetching chats:", error);
    }
  };
  const fetchUserNames = async () => {
    try {
      const response = await axios.get("/getUserName");

      if (response.data.success) {
        const currentUser = response.data.data.find(
          (user) => user.email === userEmail
        );
        const userRole = currentUser ? currentUser.role : null;

        let filteredUsers = response.data.data;

        if (userRole === "QualityAssurance") {
          filteredUsers = response.data.data.filter(
            (user) => user.role === "Instructor" || user.role === "Admin"
          );
        }

        const newUserNameMap = {};

        filteredUsers.forEach((user) => {
          newUserNameMap[user.email] = user.name;
        });

        newUserNameMap["chatbot@wdm.com"] = "ChatBot";
        setUserNameMap(newUserNameMap);

        const initialMessages = {};
        Object.keys(newUserNameMap).forEach((email) => {
          initialMessages[email] = userMessages[email] || [];
        });

        setUserMessages(initialMessages);
      }
    } catch (error) {
      console.error("Error fetching user names:", error);
    }
  };

  useEffect(() => {
    fetchChats();
    fetchUserNames();

    const intervalId = setInterval(() => {
      fetchChats();
    }, 1500);

    return () => clearInterval(intervalId);
  }, []);
  useEffect(() => {
    const updatedMessages = { ...userMessages };

    apiResponse.forEach((messageObj) => {
      const { ID, SenderEmail, ReceiverEmail, Message } = messageObj;
      const direction = SenderEmail === userEmail ? "right" : "left";
      const user = direction === "right" ? ReceiverEmail : SenderEmail;

      if (userNameMap[user]) {
        if (!updatedMessages[user]) {
          updatedMessages[user] = [];
        }

        // Check if the message is already added to avoid duplicates
        const messageAlreadyAdded = updatedMessages[user].some(
          (msg) => msg.ID === ID
        );
        if (!messageAlreadyAdded) {
          updatedMessages[user].push({
            ID, // Store the message ID
            direction,
            text: Message,
          });
        }
      }
    });

    setUserMessages(updatedMessages);
    setTimeout(scrollToBottom, 0);
  }, [apiResponse, userNameMap, userEmail]);

  useEffect(() => {
    scrollToBottom();
  }, [userMessages[selectedUser]]);

  const handleSendMessage = async () => {
    if (currentMessage.trim() !== "") {
      const formData = new URLSearchParams();
      formData.append("SenderEmail", userEmail);
      formData.append("ReceiverEmail", selectedUser);
      formData.append("Message", currentMessage);

      try {
        const response = await axios.post("/sendMessage", formData);
        if (response.data.success) {
          // Do nothing or show a success message to the user
        } else {
          console.error("Error sending message:", response.data.message);
        }
      } catch (error) {
        console.error("Error sending message:", error);
      }

      setCurrentMessage("");

      if (selectedUser === "chatbot@wdm.com") {
        setIsChatbotThinking(true);

        const systemMessage = await addMessageAndGetResponse(currentMessage);
        console.log(systemMessage);
        const formData = new URLSearchParams();
        formData.append("SenderEmail", "chatbot@wdm.com");
        formData.append("ReceiverEmail", userEmail);
        formData.append("Message", systemMessage);

        try {
          const response = await axios.post("/sendMessage", formData);
          if (!response.data.success) {
            console.error(
              "Error sending chatbot message:",
              response.data.message
            );
          }
        } catch (error) {
          console.error("Error sending chatbot message:", error);
        }
      } else {
        // The selected user is not the chatbot, proceed as normal
      }

      setIsChatbotThinking(false);
    }
  };

  const handleUserSelection = (newUserEmail) => {
    // Initialize an empty message array for the new user if not present
    setUserMessages((prevUserMessages) => {
      if (!prevUserMessages[newUserEmail]) {
        return { ...prevUserMessages, [newUserEmail]: [] };
      }
      return prevUserMessages;
    });

    // Set the new user as the selected user
    setSelectedUser(newUserEmail);
  };

  const styles = {
    typingIndicator: {
      padding: "10px", // Or any suitable padding
      color: "gray", // Or any color that fits your design
      // Add additional styling to center the indicator or animate it
    },
    container: {
      display: "flex",
      width: "100%",
      height: "500px",
    },
    sidebar: {
      flex: "1",
      borderRight: "1px solid #ccc",
      padding: "20px",
      height: "100%",
      overflowY: "auto",
      backgroundColor: "#f6f6f6",
    },
    chatBox: {
      flex: "3",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      padding: "20px",
      height: "100%",
      backgroundColor: "#fff",
    },
    chatList: {
      listStyleType: "none",
      padding: 0,
      margin: 0,
    },
    listItem: {
      padding: "10px 5px",
      cursor: "pointer",
      "&:hover": {
        backgroundColor: "#e0e0e0",
      },
    },
    leftMessage: {
      maxWidth: "60%",
      padding: "10px 15px",
      borderRadius: "15px 15px 15px 0",
      backgroundColor: "#e5e5e5",
      boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
      marginBottom: "15px",
      alignSelf: "flex-start",
    },
    rightMessage: {
      maxWidth: "60%",
      padding: "10px 15px",
      borderRadius: "15px 15px 0 15px",
      backgroundColor: "#00aaff",
      color: "white",
      boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
      marginBottom: "15px",
      alignSelf: "flex-end",
    },
    chatInput: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px",
      borderTop: "1px solid #ccc",
    },
    input: {
      padding: "10px",
      borderRadius: "15px",
      border: "1px solid #ccc",
      flex: "1",
      marginRight: "10px",
    },
    button: {
      padding: "10px 20px",
      backgroundColor: "#00aaff",
      color: "white",
      border: "none",
      borderRadius: "15px",
      cursor: "pointer",
    },

    messagesContainer: {
      maxHeight: "400px", // Changed to camelCase
      overflowY: "auto", // Changed to camelCase
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.sidebar}>
        <h2>Chats</h2>
        <ul style={styles.chatList}>
          <li style={styles.listItem}>
            <Link
              to="#"
              onClick={(e) => {
                e.preventDefault();
                handleUserSelection("chatbot@wdm.com");
              }}
            >
              ChatBot
            </Link>
          </li>
          {Object.keys(userMessages).map((email, index) => (
            <li key={index} style={styles.listItem}>
              <Link
                to="#"
                onClick={(e) => {
                  e.preventDefault();
                  handleUserSelection(email);
                }}
              >
                {userNameMap[email] || email}
              </Link>
            </li>
          ))}
        </ul>
      </div>
      <div style={styles.chatBox}>
        <div>
          <h2>{userNameMap[selectedUser] || selectedUser}</h2>
        </div>
        <div style={styles.messagesContainer} ref={messagesEndRef}>
          {userMessages[selectedUser]?.map((message) => (
            <div
              key={message.ID}
              style={
                message.direction === "left"
                  ? styles.leftMessage
                  : styles.rightMessage
              }
            >
              <p>{message.text}</p>
            </div>
          ))}
        </div>
        {isChatbotThinking && <div className="typingIndicator"></div>}
        <div style={styles.chatInput}>
          <input
            style={styles.input}
            type="text"
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
            placeholder="Type your message..."
          />
          <button style={styles.button} onClick={handleSendMessage}>
            Send
          </button>
        </div>
      </div>
    </div>
  );
}

export default Message;
