import React from 'react';

function Profile() {
  // Handle the form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Here you would typically collect the data and send it to the server
    // For example:
    // const formData = new FormData(event.target);
    // fetch('your-api-endpoint', { method: 'POST', body: formData });
    console.log('Form submitted');
  };

  return (
    <>
      <div style={{ textAlign: 'center' }}>
        <h2>Profile</h2>
      </div>

      <div className="container5" style={{ justifyContent: 'center', maxWidth: '40%', borderRadius: '10px' }}>
        <section>
          <h2>Update Your Profile</h2>
          <p>
            Please fill out the form below to update your profile details:
          </p>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
            <label htmlFor="id" style={{ margin: '5px 0' }}>ID:</label>
            <input type="text" id="id" name="userId" required style={inputStyle} />

            <label htmlFor="name" style={{ margin: '5px 0' }}>Name:</label>
            <input type="text" id="name" name="userName" required style={inputStyle} />

            <label htmlFor="email" style={{ margin: '5px 0' }}>Email:</label>
            <input type="email" id="email" name="userEmail" required style={inputStyle} />

            <label htmlFor="password" style={{ margin: '5px 0' }}>Password:</label>
            <input type="password" id="password" name="userPassword" required style={inputStyle} />

            <label htmlFor="mobile" style={{ margin: '5px 0' }}>Mobile Number:</label>
            <input type="tel" id="mobile" name="userMobile" required style={inputStyle} />

            <input type="submit" value="Update Profile" style={submitButtonStyle} />
          </form>
        </section>
      </div>
    </>
  );
}

// Define the inline styles outside of the component to keep the code clean
const inputStyle = {
  width: '90%',
  padding: '10px',
  borderRadius: '5px',
  border: '1px solid #ccc',
  marginBottom: '10px',
};

const submitButtonStyle = {
  margin: 'auto auto',
  padding: '10px',
  backgroundColor: '#007BFF',
  color: '#fff',
  borderRadius: '5px',
  border: 'none',
  fontFamily: 'Arial, sans-serif',
  cursor: 'pointer',
};

export default Profile;
