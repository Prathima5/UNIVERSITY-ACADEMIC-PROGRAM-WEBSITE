import React, { useState, useEffect } from "react";
import axios from "../../components/axios";
import { Helmet } from "react-helmet";
import Modal from "react-modal";
import "../../style.css";

Modal.setAppElement("#root");

function Policy() {
  const [policies, setPolicies] = useState([]);
  const [modalIsOpen, setIsOpen] = useState(false);
  const [policyName, setPolicyName] = useState("");
  const [policyDesc, setPolicyDesc] = useState("");
  const [policySubject, setPolicySubject] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    fetchPolicies();
  }, []);

  async function fetchPolicies() {
    try {
      const response = await axios.post("/getQAPolicies");
      if (response.data.success) {
        setPolicies(response.data.policies);
      } else {
        setErrorMessage("Error fetching policies: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error fetching policies: " + error.message);
    }
  }

  async function createPolicy(event) {
    event.preventDefault(); // Prevent the default form submit action
    try {
      const formData = new URLSearchParams();
      formData.append("policyName", policyName);
      formData.append("policyDesc", policyDesc);
      formData.append("policySubject", policySubject);

      const response = await axios.post("/insertPolicy", formData);

      if (response.data.success) {
        fetchPolicies(); // Re-fetch policies after adding a new one
        closeModal(); // Close the modal
        // Reset form fields
        setPolicyName("");
        setPolicyDesc("");
        setPolicySubject("");
      } else {
        setErrorMessage("Error adding policy: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error adding policy: " + error.message);
    }
  }

  const openModal = () => setIsOpen(true);
  const closeModal = () => setIsOpen(false);

  return (
    <>
      <Helmet>
        <title>Policy Management</title>
      </Helmet>

      <div className="policy-page">
        <div className="page-header">
          <h1 className="page-title">Policy Management</h1>
          <button className="button button-primary" onClick={openModal}>
            Create New Policy
          </button>
        </div>

        <Modal
          isOpen={modalIsOpen}
          onRequestClose={closeModal}
          className="modal"
          overlayClassName="overlay"
        >
          <div className="modal-header">
            <h2>Create New Policy</h2>
            <button className="button-close" onClick={closeModal}>
              &times;
            </button>
          </div>
          <form className="modal-form" onSubmit={createPolicy}>
            <div className="form-group">
              <label htmlFor="policyName">Policy Name:</label>
              <input
                id="policyName"
                type="text"
                value={policyName}
                onChange={(e) => setPolicyName(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="policyDesc">Policy Description:</label>
              <textarea
                id="policyDesc"
                value={policyDesc}
                onChange={(e) => setPolicyDesc(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="policySubject">Subjected to (Role):</label>
              <select
                id="policySubject"
                value={policySubject}
                onChange={(e) => setPolicySubject(e.target.value)}
                required
              >
                <option value="">Select Role</option>
                <option value="Student">Student</option>
                <option value="Teacher">Teacher</option>
                <option value="Admin">Admin</option>
              </select>
            </div>
            <div className="form-actions">
              <button className="button button-primary" type="submit">
                Submit
              </button>
            </div>
          </form>
        </Modal>

        {errorMessage && <p className="error-message">{errorMessage}</p>}

        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Policy Name</th>
                <th>Description</th>
                <th>Subjected to (Role)</th>
              </tr>
            </thead>
            <tbody>
              {policies.map((policy) => (
                <tr key={policy.id}>
                  <td>{policy.policyName}</td>
                  <td>{policy.policyDesc}</td>
                  <td>{policy.policySubject}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default Policy;
