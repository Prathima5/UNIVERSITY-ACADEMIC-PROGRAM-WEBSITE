import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import axios from "../../components/axios";

export default function Progress() {
  const [userName, setUserName] = useState("");
  const [examGrades, setExamGrades] = useState([]);
  const [filteredExamGrades, setFilteredExamGrades] = useState([]);

  // Fetch user name on mount
  useEffect(() => {
    const userEmail = localStorage.getItem("userEmail");
    const fetchUserName = async () => {
      const formData = new URLSearchParams();
      formData.append("email", userEmail);
      const response = await axios.post("/getUserInfo", formData);
      if (response.data.success) {
        setUserName(response.data.data.name);
      }
    };

    fetchUserName();
  }, []);

  // Fetch exam grades on mount
  useEffect(() => {
    const fetchExamGrades = async () => {
      const response = await axios.post("/getExamGrades");
      if (response.data.success) {
        setExamGrades(response.data.data);
      }
    };

    fetchExamGrades();
  }, []);

  // Filter exam grades whenever userName or examGrades changes
  useEffect(() => {
    const filtered = userName
      ? examGrades.filter((examGrade) => examGrade.name === userName)
      : examGrades; // Show all examGrades if userName is empty
    setFilteredExamGrades(filtered);
  }, [userName, examGrades]);

  const studentProgressData = filteredExamGrades.map((examGrade) => ({
    Course: examGrade.courseName,
    Exam: examGrade.examName,
    Grade: examGrade.grade,
    Feedback: examGrade.feedback,
  }));

  return (
    <>
      <Helmet>
        <title>Student Progress</title>
      </Helmet>
      <div style={{ backgroundColor: "#f7f7f7", padding: "20px" }}>
        <h1
          style={{
            color: "#333",
            borderBottom: "3px solid #444",
            paddingBottom: "10px",
          }}
        >
          Student Progress
        </h1>
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            marginTop: "20px",
          }}
        >
          <thead>
            <tr style={{ borderBottom: "2px solid #333" }}>
              <th style={{ padding: "10px", textAlign: "left" }}>
                Course Name
              </th>
              <th style={{ padding: "10px", textAlign: "left" }}>Exam Name</th>
              <th style={{ padding: "10px", textAlign: "left" }}>Grade</th>
              <th style={{ padding: "10px", textAlign: "left" }}>Feedback</th>
            </tr>
          </thead>
          <tbody>
            {studentProgressData.map((record, index) => (
              <tr
                key={index}
                style={{
                  backgroundColor: index % 2 === 0 ? "#fff" : "#e6e6e6",
                }}
              >
                <td style={{ padding: "10px", borderBottom: "1px solid #ccc" }}>
                  {record.Course}
                </td>
                <td style={{ padding: "10px", borderBottom: "1px solid #ccc" }}>
                  {record.Exam}
                </td>
                <td style={{ padding: "10px", borderBottom: "1px solid #ccc" }}>
                  {record.Grade}
                </td>
                <td style={{ padding: "10px", borderBottom: "1px solid #ccc" }}>
                  {record.Feedback}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
