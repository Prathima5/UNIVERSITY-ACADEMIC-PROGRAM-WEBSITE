import React from "react";
import { Helmet } from "react-helmet";
import { useState, useEffect } from "react";
import axios from "../../components/axios";

function Material() {
  const [courses, setCourses] = useState([]);
  const [course, setCourse] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  async function fetchCourses() {
    try {
      const response = await axios.post("/getCourses");

      if (response.data.success) {
        setCourses(response.data.data);
      } else {
        setErrorMessage("Error fetching courses: " + response.data.message);
      }
    } catch (error) {
      setErrorMessage("Error fetching courses: " + error);
    }
  }

  useEffect(() => {
    fetchCourses();
  }, []);

  return (
    <>
      <Helmet>
        <title>Student's Course Material</title>
      </Helmet>

      <div
        className="form-group"
        style={{ textAlign: "center", margin: "2% 35%" }}
      >
        <h2 style={{ margin: "10px 10px 20px 10px" }}>Course Material</h2>
        {/* <label htmlFor="course" >Select Course</label> */}
        <br />
        <select
          style={{
            width: "50%",
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            margin: "5px",
          }}
          value={course}
          onChange={(e) => {
            setCourse(e.target.value);
          }}
          // id="course"
          // name="course"
          placeholder="Select course"
          required
        >
          {courses.map((course) => (
            <option value={course.courseName}>{course.courseName}</option>
          ))}
        </select>
      </div>

      <h6 style={{ textAlign: "center" }}>Course Material</h6>
      <div
        style={{
          margin: " 1% 15%",
          border: "1px grey solid",
          borderRadius: "5px",
          padding: "10px",
        }}
      >
        {courses
          .filter((item) => item.courseName == course)
          .map((filterCourse) => filterCourse.courseContent)}
      </div>
    </>
  );
}

export default Material;
