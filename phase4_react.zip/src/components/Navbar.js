import React from "react";
import { NavLink } from "react-router-dom";
import logo from "../Images/logo.png";
import "./navbar.css";
import NavigationLinks from "./NavigationLinks";

export default function Navbar() {
  return (
    <header>
      <NavLink to="/" className="nav_navbar_logo-link">
        <img src={logo} alt="Logo" className="nav_navbar_logo" />
      </NavLink>

      <NavigationLinks />
    </header>
  );
}
